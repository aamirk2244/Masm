The strings example was designed to show how C++ creates
stack space for a local variable (a string).

8/15/01